import pygame
#######LOADED IMAGES#############
player = [pygame.image.load('Fisker_1.png'),pygame.image.load('Fisker_2.png'),pygame.image.load('Fisker_3.png'),pygame.image.load('Fisker_4.png'),pygame.image.load('Fisker_5.png'),pygame.image.load('Fisker_6.png'),pygame.image.load('Fisker_7.png'),pygame.image.load('Fisker_8.png')]
cloud_1 = (pygame.image.load('cloud3.png'))
sea = (pygame.image.load('sea.png'))
sea_2 = (pygame.image.load('sea_2.png'))
dirt = (pygame.image.load('brygge.png'))
background = (pygame.image.load('background.png'))
throwbar = (pygame.image.load('throw_bar.png'))
got_fish = (pygame.image.load('Fisker_0.png'))
catch = (pygame.image.load('catch.png'))
###############RARITY TEXT################################
trash_text = (pygame.image.load('trash1.png'))
legendary_text = (pygame.image.load('legendary1.png'))
rare_text = (pygame.image.load('rare1.png'))
################BILDER AV FISK##############################
fisk_rare_1 = (pygame.image.load('fisk_rare_1.png'))
fisk_trash_1 = (pygame.image.load('fisk_trash_1.png'))
fisk_legendary_1 = (pygame.image.load('fisk_legendary_1.png'))
############################################################
key_png = [pygame.image.load('blank.png'), pygame.image.load('key_1.png'), pygame.image.load('key_2.png'), pygame.image.load('key_3.png'), pygame.image.load('key_4.png'), pygame.image.load('key_5.png'),]